"""EchoZero integration bridge."""
